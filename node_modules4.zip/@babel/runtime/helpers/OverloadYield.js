function _OverloadYield(t, e) {
  this.v = t, this.k = e;
}
module.exports = _OverloadYield, module.exports.__esModule = true, module.exports["default"] = module.exports;