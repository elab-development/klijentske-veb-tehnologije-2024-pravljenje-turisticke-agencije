export declare function prune(): void;
//# sourceMappingURL=prune.d.ts.map