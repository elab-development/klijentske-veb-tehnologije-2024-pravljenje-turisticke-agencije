export declare function suppress(): void;
//# sourceMappingURL=suppress.d.ts.map