export declare function findAndConsoleLogPatchPathCli(patchPath: string): void;
export declare function getPathToLinterJS(): string;
export declare function getPathToGeneratedPatch(patchPath: string, nameOfGeneratedPatchFile: string): string;
export declare function getNameOfGeneratedPatchFile(): string;
//# sourceMappingURL=path-utils.d.ts.map