export { _ as default } from "../esm/_initializer_define_property.js";
