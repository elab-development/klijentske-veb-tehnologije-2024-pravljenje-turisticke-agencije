export { _ as default } from "../esm/_non_iterable_rest.js";
