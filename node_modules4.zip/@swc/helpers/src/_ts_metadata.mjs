export { _ as default } from "../esm/_ts_metadata.js";
