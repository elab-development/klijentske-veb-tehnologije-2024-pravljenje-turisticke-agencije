import { Brand } from "@/types/brand";

const brandsData: Brand[] = [];

export default brandsData;
