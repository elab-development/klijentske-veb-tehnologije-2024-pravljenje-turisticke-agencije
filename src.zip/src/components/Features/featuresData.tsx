import { Feature } from "@/types/feature";

const featuresData: Feature[] = [
  {
    id: 1,
    icon: (
      <img 
      src="/images/video/OIP.jfif" 
      alt="Description of image" 
      width="90" 
      height="90" 
      className="your-custom-class"
    />
    ),
    title: "Halkidiki 109 EURA",
    paragraph:
      "DATUM: 16.06/28.06",
  },
  {
    id: 1,
    icon: (
      <img 
      src="/images/video/OIP.jfif" 
      alt="Description of image" 
      width="90" 
      height="90" 
      className="your-custom-class"
    />
    ),
    title: "Halkidiki 109 EURA",
    paragraph:
      "DATUM: 16.06/28.06",
  },
  {
    id: 1,
    icon: (
      <img 
      src="/images/video/OIP.jfif" 
      alt="Description of image" 
      width="90" 
      height="90" 
      className="your-custom-class"
    />
    ),
    title: "Halkidiki 109 EURA",
    paragraph:
      "DATUM: 16.06/28.06",
  },
  {
    id: 1,
    icon: (
      <img 
      src="/images/video/OIP.jfif" 
      alt="Description of image" 
      width="90" 
      height="90" 
      className="your-custom-class"
    />
    ),
    title: "Halkidiki 109 EURA",
    paragraph:
      "DATUM: 16.06/28.06",
  },
  {
    id: 1,
    icon: (
      <img 
      src="/images/video/OIP.jfif" 
      alt="Description of image" 
      width="90" 
      height="90" 
      className="your-custom-class"
    />
    ),
    title: "Halkidiki 109 EURA",
    paragraph:
      "DATUM: 16.06/28.06",
  },
  {
    id: 1,
    icon: (
      <img 
      src="/images/video/OIP.jfif" 
      alt="Description of image" 
      width="90" 
      height="90" 
      className="your-custom-class"
    />
    ),
    title: "Halkidiki 109 EURA",
    paragraph:
      "DATUM: 16.06/28.06",
  },
];
export default featuresData;
